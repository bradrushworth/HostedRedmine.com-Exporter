package tryhttpclient;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.AuthState;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.ExecutionContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;

public class RunMe {

                static String apiAccessKey = "293a64eef15b452047a0315ecc6eff2a9bbd4a9c";
                static String host = "www.hostedredmine.com";
                static Integer port = null;
                static String protocol = "https";
                static String projectName = "taskconnector-test";
                static String userName = "java";
                static String password = "java";

                // static String apiAccessKey =
                // "fc20e8f5f1885fc194b7b7865e6d6ce9a44a4b88...";
                // static Integer port = 3000;
                // static String host = "172.17.10.53";
                // static String projectName = "ace";
                // static String protocol = "http";
                // static String userName = "admin";
                // static String password = "admin";

                static String url = protocol + "://" + host + ":" + port + "/projects/"
                                                + projectName + "/issues.xml";

                protected static String getPostURL() {
                                String urlPost = protocol + "://" + host;
                                if (port != null) {
                                                urlPost += ":" + port;
                                }

                                urlPost += "/issues.xml";
                                return urlPost;
                }

                /*
                 * static String apiAccessKey =
                 * "087a6cd6077a14fc1968af0e92949d1c6d30757a00"; static int port = 80;
                 * static String host = "redmine-test.starviewtechnology.com"; static String
                 * protocol = "http"; static String url = protocol + "://" + host + ":" +
                 * port + "/projects/tools/issues.xml";
                 */
                public static void main(String[] args) throws Exception {
//                            doGet();
                                doPost();
                }

                private static void doGet() throws Exception {
                                String url = protocol + "://" + host;
                                if (port != null) {
                                                url += ":" + port;
                                }
                                url +=  "/issues.xml?key=" + apiAccessKey;

                                HttpClient client = getClient(protocol);

                                HttpGet httpget = new HttpGet(url);
                                System.out.println("executing request:\n" + httpget.getRequestLine());
                                HttpResponse response = client.execute(httpget);
                                HttpEntity entity = response.getEntity();

                                System.out.println("----------------------------------------");
                                System.out.println(response.getStatusLine());
                                if (entity != null) {
                                                System.out.println("Response length: " + entity.getContentLength()
                                                                                + " type=" + entity.getContentType());
                                }
                                // System.out.println(EntityUtils.toString(entity));

                                // When HttpClient instance is no longer needed,
                                // shut down the connection manager to ensure
                                // immediate deallocation of all system resources
                                client.getConnectionManager().shutdown();
                }

                private static AbstractHttpClient getClient(String protocol)
                                                throws KeyManagementException, NoSuchAlgorithmException {
                                AbstractHttpClient httpClient = null;
                                if (protocol.equalsIgnoreCase("https")) {
                                                Scheme httpsScheme = new Scheme("https", getOurSSLSecurity(), 443);
                                                SchemeRegistry schemeRegistry = new SchemeRegistry();
                                                schemeRegistry.register(httpsScheme);

                                                HttpParams params = new BasicHttpParams();
                                                ClientConnectionManager cm = new SingleClientConnManager(params,
                                                                                schemeRegistry);
                                                httpClient = new DefaultHttpClient(cm, params);
//                                            httpClient.addRequestInterceptor(preemptiveAuth, 0);
                                } else if (protocol.equalsIgnoreCase("http")) {
                                                httpClient = new DefaultHttpClient();
                                } else {
                                                throw new RuntimeException("Unsupported protocol: " + protocol);
                                }
                                return httpClient;

                }

                private static void doPost() throws IOException, ClientProtocolException,
                                                KeyManagementException, NoSuchAlgorithmException, EncoderException {
                                AbstractHttpClient client = getClient(protocol);

                                CredentialsProvider credsProvider = new BasicCredentialsProvider();
                                
                                AuthScope scope =  new AuthScope(host, AuthScope.ANY_PORT);
                                credsProvider.setCredentials(scope,
                                                                new UsernamePasswordCredentials(userName, password));

                                // UsernamePasswordCredentials creds = new UsernamePasswordCredentials(
                                // userName, password);
                                client.setCredentialsProvider(credsProvider); // (AuthScope.ANY, creds);
                                HttpPost httpPost = new HttpPost(getPostURL());

//                            String toEncode =userName + ":" + password;
//                            String encoded = new String(Base64.encodeBase64(toEncode.getBytes()));
//                            httpPost.setHeader("Authorization", "Basic " + encoded);
                                
                                String xmlBody = getXMLBody();
                                System.out.println("executing request:\n" + httpPost.getRequestLine()
                                                                + "\nxml=" + xmlBody);
                                StringEntity entity = new StringEntity(xmlBody);
                                entity.setContentType("text/xml; charset=utf-8");

                                // HttpEntity entity = new EntityTemplate(cp);

                                httpPost.setEntity(entity);

                                HttpContext localContext = new BasicHttpContext();
                                HttpResponse response = client.execute(httpPost, localContext);

                                System.out.println(localContext
                                                                .getAttribute(ClientContext.TARGET_AUTH_STATE));

                                HttpEntity responseEntity = response.getEntity();

                                System.out.println("----------------------------------------");
                                System.out.println(response.getStatusLine());
                                if (responseEntity != null) {
                                                System.out.println("Response content length: "
                                                                                + responseEntity.getContentLength());
                                }
                                System.out.println(EntityUtils.toString(responseEntity));
                                client.getConnectionManager().shutdown();
                }

                /*
                 * static ContentProducer cp = new ContentProducer() { public void
                 * writeTo(OutputStream outstream) throws IOException { Writer writer = new
                 * OutputStreamWriter(outstream, "UTF-8"); String xml = //"<?xml
                 * version=\"1.0\" encoding=\"UTF-8\"?> sssssssss // writer.write("&issue="
                 * + xml); writer.write(xml); writer.flush(); } };
                 */
                private static String getXMLBody() {
                                return "<issue>" + "<subject>tex t  14 </subject>" + "<project_id>"
                                                                + projectName + "</project_id>" + "</issue>";

                }

                private static SSLSocketFactory getOurSSLSecurity()
                                                throws NoSuchAlgorithmException, KeyManagementException {
                                SSLContext sslContext = SSLContext.getInstance("SSL");

                                // set up a TrustManager that trusts everything
                                sslContext.init(null, new TrustManager[] { new X509TrustManager() {
                                                public X509Certificate[] getAcceptedIssuers() {
                                                                System.out.println("getAcceptedIssuers =============");
                                                                return null;
                                                }

                                                public void checkClientTrusted(X509Certificate[] certs,
                                                                                String authType) {
                                                                System.out.println("checkClientTrusted =============");
                                                }

                                                public void checkServerTrusted(X509Certificate[] certs,
                                                                                String authType) {
                                                                System.out.println("checkServerTrusted =============");
                                                }
                                } }, new SecureRandom());

                                SSLSocketFactory sf = new SSLSocketFactory(sslContext);
                                return sf;

                }
                
                
                private static HttpRequestInterceptor preemptiveAuth = new HttpRequestInterceptor() {
                    public void process(final HttpRequest request, final HttpContext context) throws HttpException, IOException {
                        AuthState authState = (AuthState) context.getAttribute(ClientContext.TARGET_AUTH_STATE);
                        CredentialsProvider credsProvider = (CredentialsProvider) context.getAttribute(
                                ClientContext.CREDS_PROVIDER);
                        HttpHost targetHost = (HttpHost) context.getAttribute(ExecutionContext.HTTP_TARGET_HOST);
                        
                        if (authState.getAuthScheme() == null) {
                            AuthScope authScope = new AuthScope(targetHost.getHostName(), targetHost.getPort());
                            Credentials creds = credsProvider.getCredentials(authScope);
                            if (creds != null) {
                                authState.setAuthScheme(new BasicScheme());
                                authState.setCredentials(creds);
                            }
                        }
                    }    
                };
}
